# Colojo

Colojo est un mini réseau social simplifié permettant d'obtenir des réactions (likes) et des abonnés sur différentes plateformes, principalement Instagram.

## Fonctionnalités

- Sélection de la plateforme (Instagram ou autre)
- Saisie du nombre de réactions souhaitées (entre 10 et 500 000)
- Option pour demander également des abonnés
- Insertion du lien de la publication
- Bouton "Recevoir des likes" pour envoyer la demande
- Interface propre, responsive et moderne

## Technologies utilisées

- **HTML5**  
- **CSS3**  
- **JavaScript (vanilla)**

## Déploiement

Le site est prêt à être déployé sur [Vercel](https://vercel.com/).

### Pour le mettre en ligne :
1. Cloner ou télécharger ce dépôt.
2. Connecter ton compte GitHub à Vercel.
3. Importer le projet dans Vercel.
4. Déployer en quelques clics !

## Aperçu

![Capture d'écran de Colojo](https://via.placeholder.com/800x400.png?text=Apercu+de+Colojo)

*(Remplacer l'image par une vraie capture d'écran après mise en ligne)*

## Auteur

Développé avec passion par [TonNom].
