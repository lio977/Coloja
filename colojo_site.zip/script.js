const platformSelect = document.getElementById('platform');
const likesSection = document.getElementById('likes-section');
const followersSection = document.getElementById('followers-section');
const form = document.getElementById('reaction-form');
const messageDiv = document.getElementById('message');

platformSelect.addEventListener('change', function() {
  if (platformSelect.value === 'instagram') {
    likesSection.classList.remove('hidden');
    followersSection.classList.remove('hidden');
  } else {
    likesSection.classList.add('hidden');
    followersSection.classList.add('hidden');
  }
});

form.addEventListener('submit', function(e) {
  e.preventDefault();

  const platform = platformSelect.value;
  const likes = document.getElementById('likes').value;
  const followers = document.getElementById('followers').value;
  const postLink = document.getElementById('post-link').value;

  if (platform === "instagram" && (likes < 10 || likes > 500000)) {
    messageDiv.textContent = "Erreur : Le nombre de réactions doit être entre 10 et 500000.";
    messageDiv.style.color = 'red';
    return;
  }

  messageDiv.textContent = "Ta demande a été envoyée avec succès !";
  messageDiv.style.color = 'green';

  form.reset();
  likesSection.classList.add('hidden');
  followersSection.classList.add('hidden');
});
